const config = {
    backendURL: "http://localhost:5000", // URL de votre backend
};

export default config;